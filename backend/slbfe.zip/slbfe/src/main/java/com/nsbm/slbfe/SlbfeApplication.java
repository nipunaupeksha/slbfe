package com.nsbm.slbfe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlbfeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SlbfeApplication.class, args);
	}

}
